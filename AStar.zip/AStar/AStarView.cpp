
// AStarView.cpp : CAStarView ���ʵ��
//

#include "stdafx.h"
// SHARED_HANDLERS ������ʵ��Ԥ��������ͼ������ɸѡ�������
// ATL ��Ŀ�н��ж��壬�����������Ŀ�����ĵ����롣
#ifndef SHARED_HANDLERS
#include "AStar.h"
#include<iostream>
#include<fstream>
#endif

#include "AStarDoc.h"
#include "AStarView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif
//const int ASTARWIDE=40;

// CAStarView

IMPLEMENT_DYNCREATE(CAStarView, CView)

	BEGIN_MESSAGE_MAP(CAStarView, CView)
		// ��׼��ӡ����
		ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
		ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
		ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CAStarView::OnFilePrintPreview)
		ON_WM_CONTEXTMENU()
		ON_WM_RBUTTONUP()
		ON_WM_SIZE()
		ON_WM_PAINT()
		ON_WM_LBUTTONDOWN()
		ON_COMMAND(ID_START, &CAStarView::OnStartSearch)
		ON_COMMAND(ID_RESTART, &CAStarView::OnRestart)
		ON_COMMAND(ID_DELARE, &CAStarView::OnDelare)
		ON_WM_MOUSEMOVE()
	END_MESSAGE_MAP()

	// CAStarView ����/����

	CAStarView::CAStarView():m_status(0)
	{
		// TODO: �ڴ˴����ӹ������
		start_brush.CreateSolidBrush(RGB(0,255,0));
		end_brush.CreateSolidBrush(RGB(255,0,0));
		wall_brush.CreateSolidBrush(RGB(125,128,127));
		final_pen.CreatePen(PS_SOLID, 2, RGB(140,0,140));
		line_pen.CreatePen(PS_SOLID, 1, RGB(0,138,0));
		m_pen.CreatePen(PS_SOLID,2,RGB(65,	105	,225));
		//* ע   brush pen ��֧�ָ��ƹ��캯��
		null_brush.CreateSolidBrush(RGB(255,255,255));
		//CBrush *pBrush=CBrush::FromHandle((HBRUSH)GetStockObject(NULL_BRUSH));
		for(int i=0; i<ASTARWIDE; i++)
			for(int j=0; j<ASTARWIDE; j++)
				m_charmap[i][j]='.';

	}
	CAStarView::~CAStarView()
	{
		DeleteObject(start_brush);
		DeleteObject(end_brush);
		DeleteObject(wall_brush);
		DeleteObject(m_pen);
		DeleteObject(line_pen);
		DeleteObject(final_pen);
	}

	BOOL CAStarView::PreCreateWindow(CREATESTRUCT& cs)
	{
		// TODO: �ڴ˴�ͨ���޸�
		//  CREATESTRUCT cs ���޸Ĵ��������ʽ

		return CView::PreCreateWindow(cs);
	}

	// CAStarView ����

	void CAStarView::OnDraw(CDC* /*pDC*/)
	{
		CAStarDoc* pDoc = GetDocument();
		ASSERT_VALID(pDoc);
		if (!pDoc)
			return;

		// TODO: �ڴ˴�Ϊ�����������ӻ��ƴ���
	}


	// CAStarView ��ӡ


	void CAStarView::OnFilePrintPreview()
	{
#ifndef SHARED_HANDLERS
		AFXPrintPreview(this);
#endif
	}

	BOOL CAStarView::OnPreparePrinting(CPrintInfo* pInfo)
	{
		// Ĭ��׼��
		return DoPreparePrinting(pInfo);
	}

	void CAStarView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
	{
		// TODO: ���Ӷ���Ĵ�ӡǰ���еĳ�ʼ������
	}

	void CAStarView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
	{
		// TODO: ���Ӵ�ӡ����е���������
	}

	void CAStarView::OnRButtonUp(UINT /* nFlags */, CPoint point)
	{
		ClientToScreen(&point);
		OnContextMenu(this, point);
	}

	void CAStarView::OnContextMenu(CWnd* /* pWnd */, CPoint point)
	{
#ifndef SHARED_HANDLERS
		theApp.GetContextMenuManager()->ShowPopupMenu(IDR_POPUP_EDIT, point.x, point.y, this, TRUE);
#endif
	}


	// CAStarView ���

#ifdef _DEBUG
	void CAStarView::AssertValid() const
	{
		CView::AssertValid();
	}

	void CAStarView::Dump(CDumpContext& dc) const
	{
		CView::Dump(dc);
	}

	CAStarDoc* CAStarView::GetDocument() const // �ǵ��԰汾��������
	{
		ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CAStarDoc)));
		return (CAStarDoc*)m_pDocument;
	}
#endif //_DEBUG


	
	int CAStarView::count_start=0;
	int CAStarView::count_end=0;
// CAStarView ��Ϣ��������
	void CAStarView::InitWndRect()
	{
		CPoint TopLeft, ButtomRight;
		this->GetWindowRect(&m_ViewRect);//�����ͼRECT
		ScreenToClient(&m_ViewRect);//�ú�������Ļ��ָ�������Ļ����ת�����û����ꡣm_AStarRect
		int length=0;
		length = min(m_ViewRect.Width(),m_ViewRect.Height());
		m_step=length/( 3+ASTARWIDE);
		TopLeft.x = m_ViewRect.left + m_step;
		TopLeft.y = m_ViewRect.top +m_step ;
		ButtomRight.x = TopLeft.x + m_step*ASTARWIDE;
		ButtomRight.y = TopLeft.y + m_step*ASTARWIDE;//12*20������
		m_AStarRect = CRect(TopLeft,ButtomRight);//�����Ϸ����
		ButtomRight.x=TopLeft.x +m_step;
		ButtomRight.y = TopLeft.y + m_step;//40*40������
		m_block=CRect(TopLeft,ButtomRight);
		// ���
		TopLeft.x =m_AStarRect.right+m_step;
		TopLeft.y = m_AStarRect.top +m_step*10;
		ButtomRight.x= TopLeft.x+2*m_step;
		ButtomRight.y= TopLeft.y+ 2*m_step;
		m_starblock = CRect(TopLeft,ButtomRight);
		// �յ�
		TopLeft.x =m_AStarRect.right+m_step;
		TopLeft.y = m_AStarRect.top +m_step*15;
		ButtomRight.x= TopLeft.x+2*m_step;
		ButtomRight.y= TopLeft.y+ 2*m_step;
		m_endblock = CRect(TopLeft,ButtomRight);
		// ǽ
		TopLeft.x =m_AStarRect.right+m_step;
		TopLeft.y = m_AStarRect.top +m_step*20;
		ButtomRight.x= TopLeft.x+2*m_step;
		ButtomRight.y= TopLeft.y+ 2*m_step;
		m_wallblock = CRect(TopLeft,ButtomRight);
		//��ǰ
		TopLeft.x =m_AStarRect.right+m_step;
		TopLeft.y = m_AStarRect.top +m_step*32;
		ButtomRight.x= TopLeft.x+2*m_step;
		ButtomRight.y= TopLeft.y+ 2*m_step;
		m_nowblock= CRect(TopLeft,ButtomRight);

	}
	void CAStarView::OnSize(UINT nType, int cx, int cy)
	{
		InitWndRect();
		CView::OnSize(nType, cx, cy);
		// TODO: �ڴ˴�������Ϣ�����������
	}


	void CAStarView::OnPaint()
	{
		CPaintDC dc(this); // device context for painting
		// ��Ϊ��ͼ��Ϣ���� CView::OnPaint()
		//CPen m_pen(PS_SOLID,2,RGB(65,	105	,225));
		//CBrush *pBrush=CBrush::FromHandle((HBRUSH)GetStockObject(NULL_BRUSH));
		dc.SelectObject(&m_pen);
		dc.SelectObject(&null_brush);
		dc.Rectangle(m_AStarRect);// ��Ϸ�Ŀ�
		dc.SetBkMode(TRANSPARENT);
		//��С�� ���ⶨ��һ����ˢ
		CDC *pDC = GetDC();
		//CBrush pBrush2(RGB(125,128,127));
		CBrush *pOldBrush = pDC->SelectObject(&wall_brush);  //��penѡ���豸������
	
		pDC->Rectangle(m_wallblock);
		std::string tempstr("Wall");
		TextOut(dc,m_wallblock.left, m_wallblock.top+2*m_step , tempstr.c_str(), tempstr.size());//,strlen(str_c(tempstr)));
	//	CBrush pBrush3(RGB(0,255,0));
		pDC->SelectObject(&start_brush);  //��penѡ���豸������
		pDC->Rectangle(m_starblock);
		tempstr="Start Point";
		TextOut(dc,m_starblock.left, m_starblock.top+2*m_step , tempstr.c_str(), tempstr.size());//,strlen(str_c(tempstr)));
		//CBrush pBrush4(RGB(255,0,0));
		pDC->SelectObject(&end_brush);  //��penѡ���豸������
		pDC->Rectangle(m_endblock);
		tempstr="End Point";
		TextOut(dc,m_endblock.left, m_endblock.top+2*m_step , tempstr.c_str(), tempstr.size());//,strlen(str_c(tempstr)));
		tempstr="Current State";
		pDC->SelectObject(&null_brush);  
		pDC->Rectangle(m_nowblock);
		TextOut(dc,m_nowblock.left, m_nowblock.top+2*m_step , tempstr.c_str(), tempstr.size());//,strlen(str_c(tempstr)));
		pDC->SelectObject(pOldBrush);               //�����ɻ���
		//ReleaseDC(pDC);

		//  ��դ��
		//pDC = GetDC();
		//CPen linepen(PS_SOLID, 1, RGB(0,138,0));
		CPen *pOldPen=pDC->SelectObject(&line_pen);  //��penѡ���豸������
		int astarlen= ASTARWIDE+1;
		for(int i=2; i<astarlen ; i++)
		{
			CPoint start=CPoint(m_step, m_step*i);
			CPoint end = CPoint(astarlen*m_step, m_step*i);
			pDC->MoveTo(start);
			pDC->LineTo(end);
		}
		for(int i=2; i<astarlen ; i++)
		{
			CPoint start=CPoint(m_step*i,m_step );
			CPoint end = CPoint(m_step*i,astarlen*m_step);
			pDC->MoveTo(start);
			pDC->LineTo(end);
		}
		//������·��
		//CPen finallpen(PS_SOLID, 2, RGB(140,0,140));
		pDC->SelectObject(&final_pen);
		pDC->MoveTo(m_wallblock.left,m_wallblock.top+5*m_step);

		pDC->LineTo(m_wallblock.left+2*m_step,m_wallblock.top+5*m_step);
		tempstr="Path";
		TextOut(dc,m_wallblock.left, m_wallblock.top+6*m_step , tempstr.c_str(), tempstr.size());//,strlen(str_c(tempstr)));
		pDC->SelectObject(pOldBrush);    
		pDC->SelectObject(pOldPen);               //�����ɻ���
		ReleaseDC(pDC);
	}

	void CAStarView::OnLButtonDown(UINT nFlags, CPoint point)
	{
		CDC *pDC = GetDC();

		// TODO: �ڴ�������Ϣ������������/�����Ĭ��ֵ
		if(point.x<=m_AStarRect.right && point.x>=m_step)
		{
			if(point.y>=m_AStarRect.top && point.y<=m_AStarRect.bottom)
			{
				//CBrush *pOldBrush=new CBrush ;
				int new_x=-1, new_y=-1;
				new_x = point.x/m_step-1;//%((ASTARWIDE+1));
				new_y = point.y/m_step-1;//%(ASTARWIDE+1);
				if(new_x<0|| new_x>(ASTARWIDE-1) || new_y<0|| new_y>(ASTARWIDE-1))
					return;

				m_block.left = (new_x+1)*m_step+1;
				m_block.right = m_block.left+m_step-1;
				m_block.top= (new_y+1)*m_step+1;
				m_block.bottom =m_block.top+m_step-1;
				
				switch(m_status)
				{
				case 1://���
					if('.'==m_charmap[new_x][new_y] && 0==count_start)
						{
							m_charmap[new_x][new_y]='s';
							pDC->FillRect(m_block,&start_brush);
							count_start = 1;
							findpath.startpoint_x=new_x;
							findpath.startpoint_y= new_y;
						}
						else if('s'==m_charmap[new_x][new_y])
						{
							count_start=0;
							m_charmap[new_x][new_y]='.';

							pDC->FillRect(m_block,&null_brush);
						}
					break;
				case 2://�յ�
						if('.'==m_charmap[new_x][new_y]&& 0==count_end)
						{
							count_end=1;
							m_charmap[new_x][new_y]='d';

							pDC->FillRect(m_block,&end_brush);
							findpath.endpoint_x=new_x;
							findpath.endpoint_y=new_y;
						}
						else if('d'==m_charmap[new_x][new_y])
						{
							count_end=0;
							m_charmap[new_x][new_y]='.';

							pDC->FillRect(m_block,&null_brush);
						}
					break;
				case 3://wall
						if('.'==m_charmap[new_x][new_y])
						{
							m_charmap[new_x][new_y]='x';

							pDC->FillRect(m_block,&wall_brush);

						}
						else if('x'==m_charmap[new_x][new_y])
						{
							m_charmap[new_x][new_y]='.';
							pDC->FillRect(m_block,&null_brush);
	
						}
					break;

				case 4:
					break;

				default:
					break;
				}

			}
		}
		else
		{
			int i=0;
			if ( i=InWhichRect(point) )
			{
				m_status=i;
			}	
		}

		CView::OnLButtonDown(nFlags, point);
	}
int CAStarView::InWhichRect(CPoint point)
{
	CDC *pDC = GetDC();
	if(point.x<=m_AStarRect.right+m_step|| point.x>= m_AStarRect.right+3*m_step || point.y<=m_AStarRect.top+10*m_step || point.y>=m_AStarRect.top+22*m_step)
		return 0;
	else if(point.y>m_starblock.top && point.y<m_starblock.bottom)
	{
		pDC->SelectObject(&start_brush);
		pDC->Rectangle(m_nowblock);
		return 1;
	}
	else if(point.y> m_endblock.top && point.y< m_endblock.bottom)
	{
		pDC->SelectObject(&end_brush);
		pDC->Rectangle(m_nowblock);
		return 2;
	}
	else if(point.y> m_wallblock.top && point.y< m_wallblock.bottom)
	{
		pDC->SelectObject(&wall_brush);
		pDC->Rectangle(m_nowblock);
		return 3;
	}
	//else if(point.y> m_endblock.top && point.y< m_endblock.bottom)
	//	return 2;
}

void CAStarView::OnStartSearch()
{
	// TODO: �ڴ�����������������
	if(0==count_start)
	{MessageBox("���������");return;}
	else if(0==count_end)
	{MessageBox("�������յ�");return;}

	StoreMap();
	SearchPath();
}

void CAStarView::StoreMap()
{
	using namespace std;
	ofstream fout;
	fout.open("starmap.txt",'w');
	if(!fout.is_open())
	{
		MessageBox("���ļ�ʧ�ܣ�");
		return;
	}

	for(int i=0; i<ASTARWIDE; i++)
	{
		for(int j=0; j< ASTARWIDE; j++)
		{fout<<m_charmap[j][i];}
		fout<<"\n";
	}
}


void CAStarView::SearchPath()
{
	CDC *pDC=GetDC();
	OpenList* openlist = new OpenList;
	CloseList* closelist = new CloseList;
	//closelist=NULL;
	//const OpenList* HEADOPEN= openlist;
	//const CloseList* HEADCLOSE= closelist;
	closelist->closenode=NULL;

	findpath.InitNodeMap( m_charmap,openlist);
	if(!findpath.FindDestinnation(openlist,closelist, m_charmap))
		return;
	pDC->SelectObject(&final_pen);
	Node *tempnode = &findpath.m_node[findpath.endpoint_x][findpath.endpoint_y];
	int temp_step=m_step/2+m_step;
	while(tempnode->parent->flag!=STARTPOINT)
	{
		CPoint start=CPoint(tempnode->location_x*m_step+temp_step, m_step*tempnode->location_y+temp_step);
		tempnode=tempnode->parent;
		CPoint end=CPoint(tempnode->location_x*m_step+temp_step, m_step*tempnode->location_y+temp_step);
		pDC->MoveTo(start);
		pDC->LineTo(end);
	}
		CPoint start=CPoint(tempnode->location_x*m_step+temp_step, m_step*tempnode->location_y+temp_step);
		tempnode=tempnode->parent;
		CPoint end=CPoint(tempnode->location_x*m_step+temp_step, m_step*tempnode->location_y+temp_step);
		pDC->MoveTo(start);
		pDC->LineTo(end);

}

void CAStarView::OnRestart()
{
	// TODO: �ڴ�����������������
	Invalidate();
	for(int i=0; i<ASTARWIDE; i++)
		for(int j=0; j<ASTARWIDE; j++)
			m_charmap[i][j]='.';

	count_start=0;
	count_end=0;
}


void CAStarView::OnDelare()
{
	// TODO: �ڴ�����������������
		MessageBox("����˵����������ҷ�ѡ��Ҫ���ӵ�С��\n 1������ź������յ�\n 2��û��·��ʱ����ʾ\n"
		" 3���˵������п�ʼѰ��·����ť\n 4���϶������ɶ��ǽ������\n 5��������ȡ�����ӵķ���""\n\n			���ߣ�һ·����");
}


void CAStarView::OnMouseMove(UINT nFlags, CPoint point)
{
	// TODO: �ڴ�������Ϣ������������/�����Ĭ��ֵ
	switch(nFlags)
	{
	case MK_LBUTTON:
		DrawMap(point);
		Sleep(10);
		break;
	
	}
	CView::OnMouseMove(nFlags, point);
}
void CAStarView::DrawMap(CPoint point)
{
		CDC *pDC = GetDC();

		// TODO: �ڴ�������Ϣ������������/�����Ĭ��ֵ
		if(point.x<=m_AStarRect.right && point.x>=m_step)
		{
			if(point.y>=m_AStarRect.top && point.y<=m_AStarRect.bottom)
			{
				//CBrush *pOldBrush=new CBrush ;
				int new_x=-1, new_y=-1;
				new_x = point.x/m_step-1;//%((ASTARWIDE+1));
				new_y = point.y/m_step-1;//%(ASTARWIDE+1);
				if(new_x<0|| new_x>(ASTARWIDE-1) || new_y<0|| new_y>(ASTARWIDE-1))
					return;

				m_block.left = (new_x+1)*m_step+1;
				m_block.right = m_block.left+m_step-1;
				m_block.top= (new_y+1)*m_step+1;
				m_block.bottom =m_block.top+m_step-1;

				if(3==m_status)
				{
					if('.'==m_charmap[new_x][new_y])
					{
						m_charmap[new_x][new_y]='x';
						pDC->FillRect(m_block,&wall_brush);
					}
				}
			}
		}
}
