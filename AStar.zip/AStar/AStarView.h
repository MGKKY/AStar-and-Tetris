
// AStarView.h : CAStarView ��Ľӿ�
//

#pragma once
#include "Algorithms.h"

class CAStarView : public CView
{
protected: // �������л�����
	CAStarView();
	DECLARE_DYNCREATE(CAStarView)

// ����
public:
	CAStarDoc* GetDocument() const;
	CRect m_ViewRect;//������ͼ����
	CRect m_AStarRect;
	CRect m_block;
	CRect m_starblock;
	CRect m_endblock;
	CRect m_wallblock;
	CRect m_nowblock;
	enum{ASTARWIDE=40};

	int m_step;
private:
	int m_status; //״̬ 1 ��� 2 �յ� 3 ǽ 4 line
	CBrush  start_brush;
	CBrush end_brush;
	CBrush wall_brush;
	CBrush null_brush;
	
	CPen   final_pen;
	CPen   line_pen;
	CPen m_pen;
	static int count_start;
	static int count_end;
	char m_charmap[ASTARWIDE][ASTARWIDE];
	CAlgorithms findpath;
// ����
public:
	void InitWndRect();
	void StoreMap();
	void SearchPath();

// ��д
public:
	virtual void OnDraw(CDC* pDC);  // ��д�Ի��Ƹ���ͼ
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	int InWhichRect(CPoint);
	void DrawMap(CPoint);
protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);

// ʵ��
public:
	virtual ~CAStarView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// ���ɵ���Ϣӳ�亯��
protected:
	afx_msg void OnFilePrintPreview();
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnPaint();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnStartSearch();
	afx_msg void OnRestart();
	afx_msg void OnDelare();
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
};

#ifndef _DEBUG  // AStarView.cpp �еĵ��԰汾
inline CAStarDoc* CAStarView::GetDocument() const
   { return reinterpret_cast<CAStarDoc*>(m_pDocument); }
#endif

